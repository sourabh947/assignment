-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 26, 2022 at 03:55 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.3.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `tokan`
--

CREATE TABLE `tokan` (
  `id` int(10) NOT NULL,
  `support_type` varchar(100) DEFAULT NULL,
  `platform` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `requests_by` varchar(100) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tokan`
--

INSERT INTO `tokan` (`id`, `support_type`, `platform`, `status`, `requests_by`, `description`, `created_at`, `updated_at`) VALUES
(1, 'feature_request', 'shopify', NULL, 'sourabh', 'sourabh', '2022-04-20 07:26:15', '2022-04-26 07:00:54'),
(2, 'feature_request', 'shopify', 'RESOLVED', 'sourabh', NULL, '2022-04-20 07:26:15', '2022-04-20 07:26:45'),
(4, 'feature_request', 'shopify', 'OPEN', 'sourabh', NULL, '2022-04-23 11:01:25', '2022-04-23 11:01:25'),
(13, 'feature_request', 'shopify', NULL, 'sourabh', '', '2022-04-23 22:34:43', '2022-04-26 07:02:05'),
(15, 'game_crashed', 'shopify', 'RESOLVED', 'sourabh', '', '2022-04-25 06:51:53', '2022-04-25 06:51:53'),
(16, 'Unable_to_start_or_login', 'shopify', 'RESOLVED', 'sourabh', '', '2022-04-25 06:56:27', '2022-04-25 06:56:27'),
(17, 'Unable_to_start_or_login', 'amazon', 'RESOLVED', 'sourabh', '', '2022-04-25 06:57:16', '2022-04-26 07:05:06'),
(18, 'game_crashed', 'shopify', 'CLOSED', 'sourabh', '', '2022-04-25 23:39:48', '2022-04-26 07:05:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tokan`
--
ALTER TABLE `tokan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tokan`
--
ALTER TABLE `tokan`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
