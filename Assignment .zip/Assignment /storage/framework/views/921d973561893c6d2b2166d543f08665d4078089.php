<!DOCTYPE html>
<html>

<head>
    <title>Laravel 5.8 Datatables Tutorial - ItSolutionStuff.com</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/22.0.0/classic/ckeditor.js"></script>
    <style>
        .hr {
            margin-top: 1rem;
            margin-bottom: 1rem;
            border: 0;
            border-top: 2px solid rgba(0, 0, 0, 0.1);
            background-color: aqua;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="form-row">
            <div class="col">
                <label for="platform">Ticket Requests</label>
            </div>
            <div class="col" style="padding-bottom: 2%;">
                <a href="javascript:void(0)" class="btn btn-primary float-right create" data-toggle="modal" data-target=".bd-example-modal-lg" id="create">Create</a>
            </div>
        </div>
        <hr>
        <table class="table table-bordered data-table" id="datatable">
            <thead>
                <tr>
                    <th>Ticket Number</th>
                    <th>support Type</th>
                    <th>Status</th>
                    <th>Description</th>
                    <th width="100px">Action</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
    <!--  -->
    <br>
    <br>

    <div class="container" id='newticket' style="display: none;">
        <hr class="hr">
        <h4 class="modal-title" id="update"></h4>
        <button type="button" class="close create" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
        <div class="form-row">
            <div class="col">
                <label for="platform">New Ticket</label>
            </div>
        </div>
        <form>
            <div class="form-row">
                <div class="col">
                    <label for="support_type">Support Type</label>
                    <select class="form-control" name="support_type" id="support_type">
                        <option value="">Select </option>
                        <option value="feature_request">Feature Request </option>
                        <option value="bug_fix_request">Bug Fix Request </option>
                        <option value="game_crashed">Game Crashed</option>
                        <option value="Unable_to_start_or_login">Unable to Start or Login</option>
                    </select>
                </div>
                <div class="col">
                    <label for="platform">Platform</label>
                    <select class="form-control" placeholder="Platform" name="platform" id="platform">
                        <option value="">Select</option>
                        <option value="shopify">shopify</option>
                        <option value="amazon">amazon</option>
                    </select>
                </div>
                <div class="col">
                    <label for="status">Status</label>
                    <select class="form-control" placeholder="Status" name="status" id="status">
                        <option value="">Select</option>
                        <option value="OPEN"> OPEN</option>
                        <option value="RESOLVED">RESOLVED</option>
                        <option value="CLOSED">CLOSED</option>
                    </select>
                </div>
                <div class="col">
                    <label for="inputEmail4">Requests By</label>
                    <select class="form-control" placeholder="Requests By" name="requests_by" id="requests_by">
                        <option value="">select</option>
                        <option value="sourabh">sourabh</option>
                    </select>
                </div>

            </div>
            <br>
            <label for="support_type">Description</label>
            <div id="editor">
                <p>Place some text here</p>
            </div>
            <hr class="hr">
            <button type="button" class="btn btn-primary" id="save_tokan">save</button>
        </form>
    </div>


    <div class="container" id='updateticket' style="display: none;">
        <hr class="hr">
        <h4 class="modal-title" id="update"></h4>
        <button type="button" class="close update" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
        <div class="form-row">
            <div class="col">
                <label for="platform">Update Ticket</label>
            </div>
        </div>
        <form>
            <input type="hidden" id="tokan_id" name="tokan_id">
            <div class="form-row">
                <div class="col">
                    <label class=" btn btn-danger btn-sm ">2-Agu-2022</label>
                    <div class="form-row">
                        <div class="form-group col-md-1"></div>
                        <div class="form-group col-md-11">
                            <p class="text-left"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
                                    <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                                    <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z" />
                                </svg>sourabh</p>
                            <hr>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-1"></div>
                        <div class="form-group col-md-11">
                            <p>hello</p>
                            <p>your tokan are resolve</p>
                            <hr>
                        </div>

                    </div>
                </div>
            </div>

            <div class="form-row">
                <div class="col">
                    <label class=" btn btn-danger btn-sm ">2-Agu-2022</label>
                    <div class="form-row">
                        <div class="form-group col-md-1"></div>
                        <div class="form-group col-md-11">
                            <p class="text-left"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
                                    <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                                    <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z" />
                                </svg>sourabh</p>
                            <hr>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-1"></div>
                        <div class="form-group col-md-11">
                            <p>hello</p>
                            <p>your tokan are resolve</p>
                            <hr>
                        </div>

                    </div>
                </div>
            </div>
            <br>
            <label for="support_type">Description</label>
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>

            <div class="form-group col-md-3">
                <label for="status">Status</label>
                <select class="form-control" placeholder="Status" name="updatestatus" id="updatestatus">
                    <option value="">Select</option>
                    <option value="OPEN"> OPEN</option>
                    <option value="RESOLVED">RESOLVED</option>
                    <option value="CLOSED">CLOSED</option>
                </select>
            </div>
            <hr>
            <button type="button" class="btn btn-primary" id="update_tokan">save</button>
        </form>
    </div>
</body>

<script type="text/javascript">
    $(function() {

        var table = $('.data-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('users.index')); ?>",
            columns: [{
                    data: 'id',
                    name: 'id',
                    orderable: false
                },
                {
                    data: 'support_type',
                    name: 'support_type',
                    orderable: false
                },
                {
                    data: 'platform',
                    name: 'platform',
                    orderable: false
                },
                {
                    data: 'description',
                    name: 'description',
                    orderable: false
                },
                {
                    data: 'action',
                    name: 'action',
                    orderable: false,
                    searchable: false
                },
            ]
        });

    });

    ClassicEditor.editorConfig = function(config) {
        config.height = 200;
        config.width = 'auto';
    };
    ClassicEditor
        .create(document.querySelector('#editor'))
        .catch(error => {
            console.error(error);
        });


    $(document).ready(function() {
        $("#save_tokan").click(function() {
            var support_type = $('#support_type').val();
            var platform = $('#platform').val();
            var status = $('#status').val();
            var requests_by = $('#requests_by').val();
            // var data = ClassicEditor.instances.editor1.getData();
            //console.log(Content);
            // var warehouseID = $(this).val();
            // if (warehouseID) {
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('users.creat_token')); ?>",
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "support_type": support_type,
                    "platform": platform,
                    "status": status,
                    "requests_by": requests_by
                },
                dataType: "json",
                beforeSend: function() {
                    //showOverlay();
                },
                success: function(data) {
                    $('#datatable').DataTable().ajax.reload();
                    $("#newticket").toggle();
                }
            });
        });
    })
    $(".create").click(function() {
        // assumes element with id='button'
        $("#newticket").toggle();
    });
    $(".update").click(function() {
        // assumes element with id='button'
        $("#updateticket").toggle();
    });
    $('body').on('click', '.edittokan', function() {
        var tokan_id = $(this).data('id');
        $.ajax({
            type: "POST",
            url: "<?php echo e(route('users.get_token')); ?>",
            data: {
                "_token": "<?php echo e(csrf_token()); ?>",
                "tokan_id": tokan_id
            },
            beforeSend: function() {
                //showOverlay();
            },
            success: function(data) {
                $("#updateticket").toggle();
                $('#updatestatus').val(data.data.status);
                $('#tokan_id').val(tokan_id);
            }
        });
    });

    $(document).ready(function() {
        $("#update_tokan").click(function() {
            var status = $('#updatestatus').val();
            var tokan_id = $('#tokan_id').val();
            console.log(tokan_id);
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('users.update_token')); ?>",
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "status": status,
                    "tokan_id": tokan_id
                },
                dataType: "json",
                beforeSend: function() {
                    //showOverlay();
                },
                success: function(data) {
                    $('#datatable').DataTable().ajax.reload();
                    $("#updateticket").toggle();
                }
            });
        });
    })
</script>

</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/test_project1/resources/views/welcome.blade.php ENDPATH**/ ?>