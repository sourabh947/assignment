<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('users', ['uses' => 'App\Http\Controllers\TokanController@index', 'as' => 'users.index']);
// Route::post('creat_token', ['creat_token' => 'App\Http\Controllers\TokanController@creat_token', 'as' => 'users.creat_token']);
Route::post('creat_token', [App\Http\Controllers\TokanController::class, 'creat_token'])->name('users.creat_token');
//Route::get('get_token/{id}', 'App\Http\Controllers\TokanController@get_token');
Route::post('get_token', [App\Http\Controllers\TokanController::class, 'get_token'])->name('users.get_token');

Route::post('update_token', [App\Http\Controllers\TokanController::class, 'update_token'])->name('users.update_token');
//Route::get('creat_token', 'App\Http\Controllers\TokanController@creat_token');
//Route::get('tokan', 'App\Http\Controllers\TokanController@index');
