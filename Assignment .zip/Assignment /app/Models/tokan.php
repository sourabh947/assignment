<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class tokan extends Model
{
    protected $table = 'tokan';
}
